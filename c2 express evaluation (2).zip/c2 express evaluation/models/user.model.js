const mongoose = require("mongoose");
const { stringify } = require("nodemon/lib/utils");

// USER SCHEMA
// Step 1 :- creating the schema
const userSchema = new mongoose.Schema(
  {
    firstName: { type: String, required: true },
    middleName: { type: String},
    lastName: { type: String, required: false },
    age:{type:String},
    email: { type: String, required: true, unique: true },
    address:{type:String, required: true},
    gender:{type: String, required: true},
    createdAt:{ type: String, required: true},
    updateAt:{type:String, required: true}
  },
  {
    versionKey: false,
    timestamps: true, 
  }
);

const branchSchema = new mongoose.Schema(
    {
      name: { type: String, required: true },
      
      address:{type:String, required: true},
      ifsc:{type: String, required: true},
      micr: { type: String, required: true, unique: true },
      createdAt:{ type: String, required: true},
      updateAt:{type:String, required: true}
    },
    {
      versionKey: false,
      timestamps: true, 
    }
  );
  const masterSchema = new mongoose.Schema(
    {
     
      balance: { type: String, required: true, unique: true },
      createdAt:{ type: String, required: true},
      updateAt:{type:String, required: true}
    },
    {
      versionKey: false,
      timestamps: true, 
    }
  );

  const savingSchema = new mongoose.Schema(
    {
     
        account_number: { type: String, required: true, unique: true },
      balance: { type: String, required: true, unique: true },
      interestRate: { type: String, required: true, unique: true },
      createdAt:{ type: String, required: true},
      updateAt:{type:String, required: true}
    },
    {
      versionKey: false,
      timestamps: true, 
    }
  );

  const fixedSchema = new mongoose.Schema(
    {
     
        account_number: { type: String, required: true, unique: true },
      balance: { type: String, required: true, unique: true },
      interestRate: { type: String, required: true, unique: true },
      startDate: { type: String, required: true, unique: true },
      maturityDate: { type: String, required: true, unique: true },
      createdAt:{ type: String, required: true},
      updateAt:{type:String, required: true}
    },
    {
      versionKey: false,
      timestamps: true, 
    }
  );

// Step 2 : creating the model
const User = mongoose.model("user","brach","master", "saving", "fixed", userSchema); 

module.exports = User;
