const express= require('express');

const app= express();



app.get('/users', function(req, res){
    res.send({ route: "/users"});
});



app.listen(5000, () =>{
    console.log('I am listening at 5000....');

});

